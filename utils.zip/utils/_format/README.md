Usage for tests python3 format.py test/<filename>
format.py will produce variations of formatting. Later, we can try all of them in the validation.

*Test Case Descriptions*
problem_11_attempt_1_leanabell.txt - Shows retrieving code from a ```lean4 ``` block
problem_4_attempt_7_deepseek2.txt - Shows formatting correction via outdenting
problem_11_attempt_5_deepseek1-5.txt - Shows removing `end` keyword + outdenting
problem_8_attempt_7_kimina.txt - Shows extracing proof from full statement + proof

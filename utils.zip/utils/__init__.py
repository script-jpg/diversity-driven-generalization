from ._format.format import get_proof_variants
__all__ = ["get_proof_variants"]
